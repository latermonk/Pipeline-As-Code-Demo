export const environment = {
    production: false,
    apiURL: '',
  };
  