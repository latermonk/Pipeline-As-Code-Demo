# default-environment-charts
The default git repository used when creating new GitOps based Environments
