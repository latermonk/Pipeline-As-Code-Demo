export const environment = {
  production: false,
  name: 'sandbox',
  apiURL: 'https://rth65vizrb.execute-api.eu-west-3.amazonaws.com/sandbox',
};
