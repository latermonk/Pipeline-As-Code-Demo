export const environment = {
    production: false,
    name: 'staging',
    apiURL: 'https://rth65vizrb.execute-api.eu-west-3.amazonaws.com/staging',
};
