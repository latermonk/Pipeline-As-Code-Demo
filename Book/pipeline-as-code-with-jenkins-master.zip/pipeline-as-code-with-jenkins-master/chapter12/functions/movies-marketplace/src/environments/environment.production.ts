export const environment = {
  production: true,
  name: 'production',
  apiURL: 'https://rth65vizrb.execute-api.eu-west-3.amazonaws.com/production',
};
